app.controller("calendarMain", function($scope) {
		$scope.day = moment();
});
